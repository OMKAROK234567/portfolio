import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class SaveUser extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException { res.setContentType("text/html");
         PrintWriter out = res.getWriter();
          String name = req.getParameter("Name");
          String email = req.getParameter("Email");
          String message = req.getParameter("Message");
          if (name == null || email == null || message == null ||
            name.isEmpty() || email.isEmpty() || message.isEmpty()) {
            out.println("All fields are required!"); return;
             }
            try
             {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            Connection conn = DriverManager.getConnection(
           "jdbc:mysql://localhost:3306/cop?useSSL=false&serverTimezone=UTC","root","root");
            String sql = "INSERT INTO record(Name, Email, Message) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, message);
            ps.executeUpdate();
            con.close();
            out.println("Data Saved Successfully in Resume Table!");
          } 
            catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
